using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float speed;// = 15f;
    public float laneSpeed;// = 10f;
    private Rigidbody rb;
    private int currentLane = 4;
    private Vector3 verticalTargetPosition;
    private Animator anim;
    public bool hasHit;
    //nitro
    public Camera playerCamera;
    private float nitroAmount;
    private float speedBeforeNitro;
    //--Spawn player car
    public List<GameObject> gameplayCar;
    private int gameplayCarNumber;
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        anim = GetComponent<Animator>();
        hasHit = false;
        MyCarGameplay();
    }

    private void Update()
    {
        PlayerMovement();

    }
    //VOIDS
    void MyCarGameplay()
    {
        gameplayCar[PlayerPrefs.GetInt("carselected")].SetActive(true);
        gameplayCarNumber = gameplayCar.Count;
        for (int i = 0; i < gameplayCarNumber; i++)
        {
            if (!gameplayCar[i].activeSelf) 
            {
                Destroy(gameplayCar[i]);
                //ver por que n�o est� apagando da lista
            }
        }
    }
    void ChangeLane(int direction)
    {
        int targetLine = currentLane + direction;
        if (targetLine < 0 || targetLine > 8)
            return;
        currentLane = targetLine;
        verticalTargetPosition = new Vector3((currentLane - 4), 0, 0);
    }

    void PlayerMovement()
    {
        rb.velocity = Vector3.forward * speed;

        Vector3 targetPosition = new Vector3(verticalTargetPosition.x, verticalTargetPosition.y, transform.position.z);
        transform.position = Vector3.MoveTowards(transform.position, targetPosition, laneSpeed * Time.deltaTime);

        if (hasHit == false)
        {
            transform.position = new Vector3(transform.position.x, 0.07f, transform.position.z);
            if (Input.GetKeyDown(KeyCode.A))//left
            {
                ChangeLane(-4);
            }
            if (Input.GetKeyDown(KeyCode.D))//right
            {
                ChangeLane(4);
            }
            if (Input.GetKeyDown(KeyCode.W) && nitroAmount <= 0)//nitro //onTriggerEnter
            {
                speedBeforeNitro = speed;
                nitroAmount = 1;
            }
        }
    }

    void Nitro()
    {
        Debug.Log(speedBeforeNitro - 0.05f);
        var boostPower = 20f;
        float nitroPower = speedBeforeNitro + boostPower;
        if (nitroAmount > 0)
        {
            if (speed < nitroPower)
            {
                speed = speed + 6 * Time.deltaTime;
                playerCamera.transform.position = new Vector3(playerCamera.transform.position.x, playerCamera.transform.position.y, playerCamera.transform.position.z - (1.5f * speed / nitroPower) * Time.deltaTime);
            }
            nitroAmount -= 0.15f * Time.deltaTime;
        }
        else//acabou o nitro
        {
            if (speed >= speedBeforeNitro)
            {
                speed = speed - 6 * Time.deltaTime;
                playerCamera.transform.position = new Vector3(playerCamera.transform.position.x, playerCamera.transform.position.y, playerCamera.transform.position.z + (1.5f * speedBeforeNitro / speed) * Time.deltaTime);
            }
        }  //-9.75 / -11.75
    }




    //------------------

    struct CarSpecs
    {
        public int CarStartSpeed;
        //public int Car
    }
}