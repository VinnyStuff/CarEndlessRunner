using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnObstacles : MonoBehaviour
{
    public int[] optionsToSpawn;
    //private int currentObstacles;
    //private int nextObstacles;
   // private int obstaclesBeenPassed;
    private int optionsSelected;
    public int whatInside;
    public List<int> spawnedObject = new List<int>();
    // Start is called before the first frame update
    void Start()
    {
        //optionsSelected = Random.Range(0, optionsToSpawn.Length);
        //Debug.Log(optionsSelected);
        for (int i = 0; i < optionsToSpawn.Length; i++)
        {
            whatInside = optionsToSpawn[i];
            spawnedObject.Add(whatInside);
        }

    }

    // Update is called once per frame
    void Update()
    {

    }
}
