using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CarsSpawner : MonoBehaviour
{
    public GameObject[] carSpawners;
    public GameObject[] cars;
    public List<GameObject> carsInstantiated;
    private int selectedCar;
    private int selectedSpawn;
    private int selectedCarIndex;
    private int selectedSpawnIndex;
    private Vector3 LocationOfSpawn;
    public Transform player;
    public GameObject point;

    // Start is called before the first frame update
    void Start()
    {
        SpawnCar(); SpawnCar(); SpawnCar();SpawnCar(); SpawnCar(); SpawnCar();
    }

    // Update is called once per frame
    void Update()
    {
        if (carsInstantiated.Count > 0)
        {
            for (int i = 0; i < carsInstantiated.Count; i++)
            {
                GameObject car = carsInstantiated[i];
                if (point.transform.position.z < player.position.z)
                {
                    Destroy(car);
                    carsInstantiated.Remove(car);
                }
            }
        }
    }

    void SpawnCar()
    {
        selectedCar = cars.Length;
        selectedCarIndex = Random.Range(0, selectedCar);


        selectedSpawn = carSpawners.Length;
        selectedSpawnIndex = Random.Range(0, selectedSpawn);
        LocationOfSpawn = carSpawners[selectedSpawnIndex].transform.position;

        GameObject newCar = Instantiate(cars[selectedCarIndex], LocationOfSpawn, transform.rotation);
        carsInstantiated.Add(newCar);
    }
}
