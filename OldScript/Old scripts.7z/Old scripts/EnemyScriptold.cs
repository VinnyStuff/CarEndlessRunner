using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyScript : MonoBehaviour
{
    private Rigidbody rb;
    public float speed;
    public bool hasHit;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        speed = Random.Range(6, 9);
    }

    // Update is called once per frame
    void Update()
    {
        if (hasHit == false)
        {
            MoveForward();
        }
    }

    void MoveForward()
    {
        rb.velocity = Vector3.forward * speed;
        rb.MoveRotation(Quaternion.identity);

        transform.position = new Vector3(transform.position.x, 0.5f, transform.position.z);
    }
}
