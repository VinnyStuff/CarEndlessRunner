using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class MainMenu : MonoBehaviour
{
    public GameObject[] carsToUse;
    public int carsNumber;
    private GameObject currentCar;
    public int carSelected;
    //MainMenuButtons
    public GameObject playButton;
    public GameObject settingsButton;
    public GameObject changeTheCarButton;
    public GameObject exitButton;
    //ChangeTheCar
    public GameObject rightArrow;
    public GameObject leftArrow;
    public GameObject selectThisCar;
    //CurrentSceneBool
    private bool mainMenuScene;
    private bool changeTheCarScene;

    void Start()
    {
        mainMenuScene = true;
        changeTheCarScene = false;
    }
    void Update()
    {
        SceneManagement();
        CountTheCars();
    }
    public void SceneManagement()
    {
        if (mainMenuScene == true)
        {
            playButton.SetActive(true);
            settingsButton.SetActive(true);
            changeTheCarButton.SetActive(true);
            exitButton.SetActive(true);
        }
        else
        {
            playButton.SetActive(false);
            settingsButton.SetActive(false);
            changeTheCarButton.SetActive(false);
            exitButton.SetActive(false);
        }
        if (changeTheCarScene == true)
        {
            rightArrow.SetActive(true);
            leftArrow.SetActive(true);
            selectThisCar.SetActive(true);
        }
        else
        {
            rightArrow.SetActive(false);
            leftArrow.SetActive(false);
            selectThisCar.SetActive(false);
        }
    }
    //buttonsInteractions-start
    public void ButtonPlay()
    {
        SceneManager.LoadScene(1);
        PlayerPrefs.SetInt("carselected", carSelected);
    }

    public void ButtonExit()
    {
        Application.Quit();
    }

    public void ButtonChangeTheCar()
    {
        mainMenuScene = false;
        changeTheCarScene = true;
    }

    public void RightArrowButton()
    {
        currentCar.SetActive(false);
        currentCar = carsToUse[carSelected + 1];
        currentCar.SetActive(true);
    }  
    public void LeftArrowButton()
    {
        currentCar.SetActive(false);
        currentCar = carsToUse[carSelected - 1];
        currentCar.SetActive(true);
    }
    public void SelectThisCarButton()
    {
        //cachear o veiculo atual
        changeTheCarScene = false;
        mainMenuScene = true;
    }
    //buttonsInteractions-end


    void CountTheCars()
    {
        carsNumber = carsToUse.Length;
        for (carSelected = 0; carSelected < carsNumber; carSelected++)
        {
            if (carsToUse[carSelected].activeSelf)
            {
                currentCar = carsToUse[carSelected];
                //Debug.Log(currentCar = carsToUse[carSelected + 1]);
                break;
            }
        }
        if (changeTheCarScene == true)
        {
            if (currentCar == carsToUse[0])
            {
                leftArrow.SetActive(false);
            }
            else
            {
                leftArrow.SetActive(true);
            }
            if (currentCar == carsToUse[carsNumber - 1])
            {
                rightArrow.SetActive(false);
            }
            else
            {
                rightArrow.SetActive(true);
            }
        }
    }
}
